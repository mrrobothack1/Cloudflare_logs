
// const CSE = require('../cse')
// const { bqscc } = require('../index')

// exports.command = 'scc'

// exports.describe = 'Post findings from BigQuery to SCC'

// exports.builder = {}

// exports.handler = async function callCse (argv) {
//   const args = argv._[1]
//   if (args === 'post') return bqscc()
//   const cse = await CSE.init()
//   cse[`${args[1]}`]()
// }
