#!/bin/bash

npm install && chmod +x setup
